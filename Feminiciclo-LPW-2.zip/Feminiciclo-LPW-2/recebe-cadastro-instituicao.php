<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Instituiçao</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
  
</head>
  
<body>
  
  <section class="menu-cadastro-instituicao">
        <section class="navegacao">
          <h1>Instituição</h1>
        <p>Informações da Instituição Cadastrada</p>  
  </section>
<?php
    require_once("CadastroInstituicao.class.php");

    $nomeInstituicao = $_POST["nomeInstituicao"];
    $enderecoInstituicao = $_POST["enderecoInstituicao"];
    $tipo = $_POST["tipo"];

    $objetoInstituicao = new Instituicao($nomeInstituicao, $enderecoInstituicao, $tipo);
    $objetoInstituicao->dadosInstituicao();
    $objetoInstituicao->inserirInstituicao();