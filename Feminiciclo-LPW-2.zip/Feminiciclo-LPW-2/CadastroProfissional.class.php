<?php
 class Profissional {
     private $cpf;
     private $formacao;
     private $horario;
     private $forma;

    public function dadosProfissional(){
        echo "<br />";
        echo "O CPF da ". __CLASS__ ." é: ". $this->cpf;
        echo "<br />";
        echo "A area de formação do(a)". __CLASS__ ." é: ". $this->formacao;
        echo "<br />";
        echo "O horario de atendimento do(a) ".__CLASS__." é: ". $this->horario;
        echo "<br />";
        echo "A forma de atendimento do(a) ".__CLASS__." é (online ou presencial): ". $this->forma;
    } 
    public function __construct($cpf, $formacao, $horario, $forma){
        $this->cpf = $cpf;
        $this->formacao = $formacao;
        $this->horario = $horario;
        $this->forma = $forma;
        echo "<br />Dados do Profissional enviados com sucesso!";
        echo "<br />";
    
    }
    public function setCPF($cpf){
        $this->cpf = $cpf;
    }
    public function getCPF(){
        return $this->cpf;
    }
    public function setFormacao($formacao){
        $this->formacao = $formacao;
    }
    public function getFormacao(){
        return $this->formacao;
    }
    public function setHorario($horario){
        $this->horario = $horario;
    }
    public function getHorario(){
        return $this->horario;
    }
    public function setForma($forma){
        $this->forma = $forma;
    }
    public function getForma(){
        return $this->forma;
    }

    public function inserirProfissional()
        {
            //Conectar com o BD
            $conexao = mysqli_connect("localhost","root","", "feminiciclo");
            
            //Verificando a conexão
            if(!$conexao){
                die("Falha na conexão com o BD");
            }
            echo"<br />";
            echo "<br />";
            echo "Profissional adicionada com sucesso!";

            //Criando a string de inserção (código SQL)
            $sql = "INSERT INTO profissional VALUES ('$this->cpf', '$this->formacao', '$this->horario', '$this->forma')";
           
            //Executando a inserção e verificando sucesso
            if(mysqli_query($conexao, $sql)){
                echo"<br />";
                echo "Conectado com o banco";
                
            }else{
                echo "Erro: ".mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
 }