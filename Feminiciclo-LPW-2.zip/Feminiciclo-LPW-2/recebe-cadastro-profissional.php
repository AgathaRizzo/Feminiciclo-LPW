<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Profissional</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>

  <body>

    <section class="menu-cadastro-profissional">
      <section class="navegacao">
        <h1>Profissional</h1>
        <p>Informações do(a) Profissional cadastrado(a):</p>
      </section>

<?php
    require_once("CadastroProfissional.class.php");

    $cpf = $_POST["cpf"];
    $formacao = $_POST["formacao"];
    $horario = $_POST["horario"];
    $forma = $_POST["forma"];

    $objetoProfissional = new Profissional($cpf, $formacao, $horario, $forma);
    $objetoProfissional->dadosProfissional();
    $objetoProfissional->inserirProfissional();
 ?>

</body>
</html>