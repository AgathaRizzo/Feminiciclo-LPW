function alertarSocorro(){
  var resposta = document.getElementById("resposta");
  resposta ="Chamando a polícia (190)...";
  alert(resposta);
}
function registrarDadosVitimas(){
  var nome = document.forms["formulario-vitima"]["nome"];
  var sobrenome = document.forms["formulario-vitima"]["sobrenome"];
  var idade = document.forms["formulario-vitima"]["idade"];
  var rg = document.forms["formulario-vitima"]["rg"];
  var mensagem = document.getElementById("mensagem");
  var mensagem1 = document.getElementById("mensagem1");
  var mensagem2 = document.getElementById("mensagem2");
  var mensagem3 = document.getElementById("mensagem3");
  var mensagem31 = document.getElementById("mensagem31");

if(nome.value==""){
    nome.classList.add("erro");
    mensagem.innerHTML = "Preencha este campo";
    mensagem.style.color="red";
    return false;
}else{
    nome.classList.remove("erro");
    nome.classList.add("sucesso"); 
  }
if(sobrenome.value==""){
    sobrenome.classList.add("erro");
    mensagem1.innerHTML = "Preencha este campo";
    mensagem1.style.color="red";
    return false;
}else{
    sobrenome.classList.remove("erro");
    sobrenome.classList.add("sucesso"); 
  }
if(idade.value==""){
    idade.classList.add("erro");
    mensagem2.innerHTML = "Preencha este campo";
    mensagem2.style.color="red";
    return false;
}else{
    idade.classList.remove("erro");
    idade.classList.add("sucesso"); 
  }
if(rg.value==""){
    rg.classList.add("erro");
    mensagem3.innerHTML = "Preencha este campo";
    mensagem3.style.color="red";
    return false;
}else{
    rg.classList.remove("erro");
    rg.classList.add("sucesso"); 
  }
if(rg.value.length <= 9){
    rg.classList.add("erro");
    mensagem31.innerHTML = "Tamanho de RG inválido, digite 9 números";
    mensagem31.style.color="red";
    return false;
  }
  else{
    rg.classList.remove("erro");
    rg.classList.add("sucesso");
  }
return true;
}

function registrarDadosProfissional(){
  var cpf = document.forms["formulario-profissional"]["cpf"];
  var formacao = document.forms["formulario-profissional"]["formacao"];
  var forma = document.forms["formulario-profissional"]["forma"];
  var mensagem4 = document.getElementById("mensagem4");
  var mensagem5 = document.getElementById("mensagem5");
  var mensagem6 = document.getElementById("mensagem6");
  var mensagem7 = document.getElementById("mensagem7");
  
  
  if(cpf.value==""){
    cpf.classList.add("erro");
    mensagem4.innerHTML = "Preencha este campo";
    mensagem4.style.color="red";
    return false;
  }else{
    cpf.classList.remove("erro");
    cpf.classList.add("sucesso"); 
  }
  if(cpf.value.length < 11){
    cpf.classList.add("erro");
    mensagem5.innerHTML = "Tamanho de CPF inválido, digite 11 números";
    mensagem5.style.color="red";
    return false;
  }
  else{
    cpf.classList.remove("erro");
    cpf.classList.add("sucesso");
  }
  if(formacao.value==""){
    formacao.classList.add("erro");
    mensagem6.innerHTML = "Preencha este caampo";
    mensagem6.style.color="red";
    return false;
  }else{
    formacao.classList.remove("erro");
    formacao.classList.add("sucesso"); 
  }
  if(forma.value==""){
    forma.classList.add("erro");
    mensagem7.innerHTML = "Selecione este campo";
    mensagem7.style.color="red";
    return false;
  }else{
    forma.classList.remove("erro");
    forma.classList.add("sucesso"); 
  }
  return true;
}

function registrarDadosInstituicao(){
  var nomeInstituicao = document.forms["formulario-instituicao"]["nomeInstituicao"];
  var enderecoInstituicao = document.forms["formulario-instituicao"]["enderecoInstituicao"];
  var tipo = document.forms["formulario-instituicao"]["tipo"];
  var mensagem8 = document.getElementById("mensagem8");
  var mensagem9 = document.getElementById("mensagem9");
  var mensagem10 = document.getElementById("mensagem10");

  if(nomeInstituicao.value==""){
    nomeInstituicao.classList.add("erro");
    mensagem8.innerHTML = "Preencha este campo";
    mensagem8.style.color="red";
    return false;
  }else{
    nomeInstituicao.classList.remove("erro");
    nomeInstituicao.classList.add("sucesso"); 
  }
}




  

  
