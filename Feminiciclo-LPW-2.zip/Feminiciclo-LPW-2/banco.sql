CREATE DATABASE feminiciclo;
USE feminiciclo;
CREATE TABLE instituicao(
    nomeInstituicao VARCHAR(100),
    enderecoInstituicao VARCHAR(100),
    tipo VARCHAR(300)
);
CREATE TABLE profissional(
    cpf VARCHAR(11),
    formacao VARCHAR(100),
    horario VARCHAR(100),
    forma VARCHAR(50)
);
CREATE TABLE vitima(
    nome VARCHAR(100),
    sobrenome VARCHAR(100),
    idade INT(3),
    rg VARCHAR(9),
    boletim VARCHAR(3)
);