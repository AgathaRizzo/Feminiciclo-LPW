<?php
 class Vitima {
     private $nome;
     private $sobrenome;
     private $idade;
     private $rg;
     private $boletim;

    public function dadosVitima(){
        echo "<br />";
        echo "O nome da ". __CLASS__ ." é: ". $this->nome;
        echo "<br />";
        echo "Sobrenome da ". __CLASS__ ." é: ". $this->sobrenome;
        echo "<br />";
        echo "Idade da ".__CLASS__." é: ". $this->idade;
        echo "<br />";
        echo "Rg da ".__CLASS__." é: ". $this->rg;
        echo "<br />";
        echo "Boletim de Ocorrência (sim ou não) : ". $this->boletim;
    } 
    public function __construct($nome, $sobrenome, $idade, $rg, $boletim){
        $this->nome = $nome;
        $this->sobrenome = $sobrenome;
        $this->idade = $idade;
        $this->rg = $rg;
        $this->boletim = $boletim;
        echo "<br />Dados de vítima enviados com sucesso!";
        echo "<br />";
    }
    public function setNome($nome){
        $this->nome = $nome;
    }
    public function getNome(){
        return $this->nome;
    }
    public function setSobrenome($sobrenome){
        $this->sobrenome = $sobrenome;
    }
    public function getSobrenome(){
        return $this->sobrenome;
    }
    public function setIdade($idade){
        $this->idade = $idade;
    }
    public function getIdade(){
        return $this->idade;
    }
    public function setRG($rg){
        $this->rg = $rg;
    }
    public function getRG(){
        return $this->rg;
    }
    public function setBoletim($boletim){
        $this->boletim = $boletim;
    }
    public function getBoletim(){
        return $this->boletim;
    }

    public function inserirVitima()
        {
            //Conectar com o BD
            $conexao = mysqli_connect("localhost","root","", "feminiciclo");
            
            //Verificando a conexão
            if(!$conexao){
                die("Falha na conexão com o BD");
            }
            echo "<br />";
            echo "<br />";
            echo "Vitima adicionada com sucesso!";
            

            //Criando a string de inserção (código SQL)
            $sql = "INSERT INTO vitima VALUES ('$this->nome', '$this->sobrenome', '$this->idade', '$this->rg', '$this->boletim')";
           
            //Executando a inserção e verificando sucesso
            if(mysqli_query($conexao, $sql)){
                echo "<br />";
                echo "Conectado com o banco";
            }else{
                echo "Erro: ".mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
 }