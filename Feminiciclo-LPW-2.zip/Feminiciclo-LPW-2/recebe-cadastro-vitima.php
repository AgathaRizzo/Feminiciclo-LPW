<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Vítima</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>
  
<body>

  <section class="menu-cadastro-vitima">
          <section class="navegacao">
       <h1>Vitima</h1>
       <p>Informações da vítima cadastrada:</p> 
    </section>
<?php
    require_once("CadastroVitima.class.php");

    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $idade = $_POST["idade"];
    $rg = $_POST["rg"];
    $boletim = $_POST["boletim"];

    $objetoVitima = new Vitima($nome, $sobrenome, $idade, $rg, $boletim);
    $objetoVitima->dadosVitima();
    $objetoVitima->inserirVitima();
    ?>
    </section>

</body>
</html>